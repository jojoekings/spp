<?php 
session_start();
include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = "select * from petugas where username='$username' and password='$password'";
$query1 = "select * from siswa where nisn='$username' and password='$password'";

$data = mysqli_query($koneksi,$query);
$data1 = mysqli_query($koneksi,$query1);

$cek = mysqli_num_rows($data);
$cek1 = mysqli_num_rows($data1);
if($cek>0 || $cek1>0){
    $row = mysqli_fetch_array($data);
    $row1 = mysqli_fetch_array($data1);

    if($row['level'] == 'admin' || $row['level'] == 'petugas'){
        $_SESSION['username'] = $row['username'];
        $_SESSION['level'] = $row['level'];
        $_SESSION['id_petugas'] = $row['id_petugas'];


        header("location:petugas/dashboard.php");

    }else{
        $_SESSION['nisn'] = $row1['nisn'];
        $_SESSION['password'] = $row1['password'];
        $_SESSION['nama'] = $row1['nama'];

        header("location:siswa/dashboard.php");
    }

}else{
    header("location:index.php");
}
