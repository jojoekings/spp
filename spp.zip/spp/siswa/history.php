<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>

<body>
    <?php
    include '../koneksi.php';
    session_start();


    include 'navbar.php';

    ?>

    <div class="container mt-3">

        <h2>History Pembayaran</h2>
        <br>
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN</th>
                    <th>Tanggal bayar</th>
                    <th>Bulan di bayar</th>
                    <th>Tahun di bayar</th>
                    <th>jumlah bayar</th>
                </tr>
            </thead>
            <tbody id="myTable">
                <?php
                $nisn = $_SESSION['nisn'];
                $query = mysqli_query($koneksi, "SELECT * FROM pembayaran  where nisn = '$nisn' ");
                $no = 1;
                while ($row = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $row['nisn'] ?></td>
                        <td><?= $row['tgl_bayar'] ?></td>
                        <td><?= $row['bulan_bayar'] ?></td>
                        <td><?= $row['tahun_bayar'] ?></td>
                        <td><?= $row['jumlah_bayar'] ?></td>
                    </tr>
                <?php $no++;
                } ?>
            </tbody>
        </table>
    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>