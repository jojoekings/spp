-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2023 at 06:45 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_spp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_kelas` (IN `id_kls` INT)  BEGIN
DELETE FROM kelas WHERE id_kelas=id_kls;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_petugas` (IN `ptgs` INT)  BEGIN
DELETE FROM petugas WHERE id_petugas=ptgs;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_siswa` (IN `nsn` CHAR(10))  BEGIN
DELETE FROM siswa WHERE nisn=nsn;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_spp` (IN `spp` INT)  BEGIN
DELETE FROM spp WHERE id_spp=spp;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `input_kelas` (IN `nme_kls` VARCHAR(10), IN `kompe` VARCHAR(50))  BEGIN
INSERT INTO kelas VALUES(null,nme_kls,kompe);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `input_pembayaran` (IN `id_ptgs` INT, IN `nsn` VARCHAR(10), IN `tgl` DATE, IN `bulan` VARCHAR(8), IN `tahun` VARCHAR(4), IN `idspp` INT, IN `jumlah` INT)  BEGIN
INSERT INTO pembayaran VALUES(null,id_ptgs,nsn,tgl,bulan,tahun,idspp,jumlah);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `input_petugas` (IN `usernm` VARCHAR(25), IN `pass` VARCHAR(32), IN `nme_ptgs` VARCHAR(35), IN `lvl` ENUM('admin','petugas'))  BEGIN
INSERT INTO petugas VALUES(null,usernm,pass,nme_ptgs,lvl);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `input_siswa` (IN `nsn` CHAR(10), IN `ns` CHAR(8), IN `nme` VARCHAR(35), IN `id_kls` INT, IN `almt` TEXT, IN `n_tlpn` VARCHAR(13), IN `pass` VARCHAR(30))  BEGIN
insert into siswa values(nsn,ns,nme,id_kls,almt,n_tlpn,pass);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `input_spp` (IN `thn` INT, IN `nmnl` INT)  BEGIN
INSERT INTO spp VALUES(null,thn,nmnl);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `upd_kelas` (IN `nama` VARCHAR(10), IN `kompe` VARCHAR(50), IN `id` INT)  BEGIN
update kelas set nama_kelas=nama,kompetensi_keakhlian=kompe where id_kelas=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `upd_petugas` (IN `user` VARCHAR(25), IN `pass` VARCHAR(32), IN `nama` VARCHAR(35), IN `lvl` ENUM('admin','petugas','',''), IN `id` INT)  BEGIN
update petugas set username=user,password=pass,nama_petugas=nama,level=lvl where id_petugas=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `upd_siswa` (IN `ns` CHAR(8), IN `nme` CHAR(35), IN `id_kls` INT, IN `almt` TEXT, IN `n_tlpn` VARCHAR(13), IN `pass` VARCHAR(30), IN `nsn` CHAR(10))  BEGIN
update siswa set nis=ns,nama=nme,id_kelas =id_kls,alamat=almt,no_telp=n_tlpn,password=pass where nisn=nsn;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `upd_spp` (IN `thn` INT, IN `nmnl` INT, IN `idspp` INT)  BEGIN
UPDATE spp SET tahun=thn,nominal=nmnl WHERE id_spp=idspp;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(10) NOT NULL,
  `kompetensi_keakhlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `kompetensi_keakhlian`) VALUES
(22, '10 pplg 1', 'Pengembangan Perangkat Lunak dan Gim'),
(24, '11 pplg 1', 'Pengembangan Perangkat Lunak dan Gim'),
(25, '11 DKV', 'Desain Komunikasi Visual');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `bulan_bayar` varchar(8) NOT NULL,
  `tahun_bayar` varchar(4) NOT NULL,
  `id_spp` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_petugas`, `nisn`, `tgl_bayar`, `bulan_bayar`, `tahun_bayar`, `id_spp`, `jumlah_bayar`) VALUES
(17, 1, '123', '2023-10-03', 'Januari', '2023', 10, 1),
(18, 6, '2130812', '2023-10-03', 'Januari', '2023', 6, 100000000),
(19, 6, '2130812', '2023-10-03', 'April', '2023', 6, 100000),
(20, 1, '123', '2023-10-07', 'Januari', '1000', 6, 10000000),
(27, 1, '123', '2023-10-06', 'Januari', '', 10, 2138123),
(28, 6, '123', '2023-10-06', 'Septembe', '2023', 10, 1000000),
(29, 1, '123', '2023-10-06', 'Januari', '2023', 6, 100000000);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama_petugas` varchar(35) NOT NULL,
  `level` enum('admin','petugas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `username`, `password`, `nama_petugas`, `level`) VALUES
(1, 'admin', 'admin', 'Admin', 'admin'),
(6, 'petugas', 'petugas', 'petugas', 'petugas'),
(10, 'joel', '123', 'jo', 'admin'),
(11, 'jo', '123', 'jo', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nisn` char(10) NOT NULL,
  `nis` char(8) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(13) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nisn`, `nis`, `nama`, `id_kelas`, `alamat`, `no_telp`, `password`) VALUES
('123', '123', 'jo', 22, 'imam', '213', '11'),
('12345', '1231', 'joele', 25, 'imam bonjol', '082391', '123'),
('381298', '21839', 'joooooooooo', 24, 'hidasdhsidh', '1391', '123');

-- --------------------------------------------------------

--
-- Table structure for table `spp`
--

CREATE TABLE `spp` (
  `id_spp` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `nominal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `spp`
--

INSERT INTO `spp` (`id_spp`, `tahun`, `nominal`) VALUES
(6, 2023, 100000),
(10, 2023, 100000),
(11, 2025, 1000001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nisn`);

--
-- Indexes for table `spp`
--
ALTER TABLE `spp`
  ADD PRIMARY KEY (`id_spp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `spp`
--
ALTER TABLE `spp`
  MODIFY `id_spp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
