<div class="content-wrapper">

  <div class="content">
    <div class="container">
      <div class="col-md-12">
        <div class="card card-outline card-info">
          <div class="card-body">
            <div class="row">

              <div class="col-lg-3 col-6">

                <!-- small card -->
                <div class="small-box bg-info">
                  <h3>Data Siswa</h3>
                  <div class="inner">
                    <?php
                    include '../koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "select * from siswa");
                    $jumlah_siswa = mysqli_num_rows($data);
                    ?>
                    <h3> <?php echo $jumlah_siswa; ?></h3>
                  </div>
                  <div class="icon">
                    <i class="fas fa-user"></i>
                  </div>
                  <a href="siswa.php" class="small-box-footer">
                    Clik Here! <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-6">

                <!-- small card -->
                <div class="small-box bg-info">
                  <h3>Data Spp</h3>
                  <div class="inner">
                    <?php
                    include '../koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "select * from spp");
                    $jumlah_spp = mysqli_num_rows($data);
                    ?>
                    <h3> <?php echo $jumlah_spp; ?></h3>
                  </div>
                  <div class="icon">
                    <i class="fas fa-user"></i>
                  </div>
                  <a href="spp.php" class="small-box-footer">
                    Clik Here! <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-6">

                <!-- small card -->
                <div class="small-box bg-info">
                  <h3>Data Kelas</h3>
                  <div class="inner">
                    <?php
                    include '../koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "select * from kelas");
                    $jumlah_kelas = mysqli_num_rows($data);
                    ?>
                    <h3> <?php echo $jumlah_kelas; ?></h3>
                  </div>
                  <div class="icon">
                    <i class="fas fa-user"></i>
                  </div>
                  <a href="kelas.php" class="small-box-footer">
                    Clik Here! <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-6">

                <!-- small card -->
                <div class="small-box bg-info">
                  <h3>Data petugas</h3>
                  <div class="inner">
                    <?php
                    include '../koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi, "select * from petugas");
                    $jumlah_petugas = mysqli_num_rows($data);
                    ?>
                   <h3> <?php echo $jumlah_petugas; ?></h3>
                  </div>
                  <div class="icon">
                    <i class="fas fa-user"></i>
                  </div>
                  <a href="petugas.php" class="small-box-footer">
                    Clik Here! <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->
</div>