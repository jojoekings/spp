<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
</head>

<body>
    <?php
    session_start();
    include 'navbar.php';
    ?>
    <div class="container mt-5">
        <div class="card p-3 shadow" style="max-width: 10000px;">
            <h2 class="text-center p-3">History Pembayaran</h2>
            <a href="transaksi.php"><button class="btn btn-primary">Tambah Pembayaran</button></a><br>
            <div class="tab-content p-3 border bg-light">
                <form action="users.php" method="GET" class="">
                    <table class="table table-striped" id="myTable">

                        <tr>
                        <tr>
                            <th>no pembayaran</th>
                            <th>Nama petugas</th>
                            <th>nisn</th>
                            <th>Nama</th>
                            <th>tanggal bayar</th>
                            <th>bulan bayar</th>
                            <th>tahun bayar</th>
                            <th>spp</th>
                            <th>jumlah bayar</th>
                        </tr>
                        <?php
                        include '../koneksi.php';
                        $query = "select * from pembayaran join petugas on petugas.id_petugas=pembayaran.id_petugas join siswa on siswa.nisn=pembayaran.nisn join spp on spp.id_spp=pembayaran.id_spp";
                        $no = 1;
                        $data = mysqli_query($koneksi, $query);
                        while ($d = mysqli_fetch_array($data)) {
                        ?>

                            <tbody>
                                <tr>
                                    <td><?= $no ?></td>
                                    <td><?= $d['nama_petugas'] ?> </td>
                                    <td><?= $d['nisn'] ?></td>
                                    <td><?= $d['nama'] ?></td>
                                    <td><?= $d['tgl_bayar'] ?></td>
                                    <td><?= $d['bulan_bayar'] ?></td>
                                    <td><?= $d['tahun_bayar'] ?></td>
                                    <td>Rp.<?= number_format($d['nominal'], 2, ",", ".") ?></td>
                                    <td>Rp.<?= number_format($d['jumlah_bayar'], 2, ",", ".") ?></td>
                                    <td>
                                </tr>
                            <?php $no++;
                        }
                            ?>
                    </table>

                </form>
            </div>
        </div>
    </div>
</body>

</html>

