<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                Masukan Pembayaran
            </div>
            <div class="card-body">
                <form class="row g-3" action="tambah/input_transaksi.php" method="post">
                    <input type="hidden" name="id_petugas" class="form-control" value="<?= $_SESSION['id_petugas'] ?>" readonly>
                    <div class="col-md-6">
                        <label for="" class="form-label">Nisn</label>
                        <select name="nisn" id="nisn" class="form-select">
                            <?php
                            include '../koneksi.php';
                            $data = mysqli_query($koneksi, "select * from siswa");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['nisn'] ?>"><?= $d['nisn'] ?></option>
                            <?php
                            }
                            ?>
                        </select>

                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Nama</label>
                        <select name="nama" id="nama" class="form-select">
                            <?php
                            include '../koneksi.php';
                            $data = mysqli_query($koneksi, "select * from siswa");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['nisn'] ?>"><?= $d['nama'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Tanggal Bayar</label>
                        <input type="date" name="tgl_bayar" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Bulan Pembayaran</label>
                        <select name="bulan_bayar" class="form-select">
                            <option value="Januari">Januari</option>
                            <option value="Febuari">Febuari</opt1on>
                            <option value="Maret">Maret</option>
                            <option value="April">April</option>
                            <option value="Mei">Mei</option>
                            <option value="Juni">Juni</option>
                            <option value="Juli">Juli</option>
                            <option value="Agustus">Agustus</option>
                            <option value="September">September</option>
                            <option value="Oktober">Oktober</option>
                            <option value="November">November</option>
                            <option value="Desember">Desember</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Tahun Pembayaran</label>
                        <input type="number" name="tahun_bayar" id="" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Nominal</label>
                        <select name="id_spp" id="" class="form-select">
                            <?php
                            include '../koneksi.php';
                            $data = mysqli_query($koneksi, "select * from spp");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['id_spp'] ?>"><?= $d['nominal'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <div class="text-center">
                            <label for="" class="form-label ">Jumlah Bayar</label>
                        </div>
                        <input type="number" name="jumlah_bayar" class="form-control">

                    </div>
                    <center>
                        <div class="col-md-6">
                            <button type="submit" class="form-control btn btn-primary">Simpan</button>
                        </div>
                    </center>
                </form>
                <div class="mt-3">
                    <a href="history.php"><button type="submit" class="form-control btn btn-secondary">Close</button></a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>