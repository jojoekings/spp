<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>
<style>
    @media print {
        .noprint {
            display: none;
        }

    }
</style>

<body>
    <?php
    error_reporting(0);
    include '../koneksi.php';
    session_start();

    

    ?>

    <div class="tab-content">
        <div id="tab1" class="container tab-pane active">
            <h2>Data Pembayaran</h2>
            <table class="table table-striped table-dark">

                <tbody>
                    <?php
                    $id_pembayaran = $_GET['id_pembayaran'];
                    $query = "SELECT * from pembayaran where id_pembayaran = '$id_pembayaran'";
                    $data = mysqli_query($koneksi, $query);
                    $d = mysqli_fetch_array($data); {
                    ?>
                        <table class="table table-bordered">
                            <tr>
                                <td><b>NISN</b></td>
                                <td><?= $d['nisn'] ?></td>
                            </tr>
                            <tr>
                                <td><b>Tanggal dibayar</b></td>
                                <td><?= $d['tgl_bayar'] ?></td>
                            </tr>
                            <tr>
                                <td><b>Bulan dibayar</b></td>
                                <td><?= $d['bulan_bayar'] ?></td>
                            </tr>
                            <tr>
                                <td><b>Tahun dibayar</b></td>
                                <td><?= $d['tahun_bayar'] ?> </td>
                            </tr>
                            <tr>
                                <td><b>Jumlah bayar</b></td>
                                <td><?= $d['jumlah_bayar'] ?></td>
                            </tr>
                        </table>
                    
                    <div class="col-4">
                       

                        <form action="" method="post">
                        <button class="btn btn-primary noprint" onclick="window.print()">Print</button>
                        <button class="btn btn-primary noprint" name="excel" type="submit">Excel</button>
                        </form>
                       
   
                     <?php
                     if(isset($_POST['excel'])){
                        header("Content-type: application/vnd-ms-excel");
                        header("Content-Disposition: attachment; filename=Data" .$d['nisn'].".xls");
                    }
                    }
                    ?>
                        <!-- <button class="btn btn-primary noprint" >
                            
	// header("Content-type: application/vnd-ms-excel");
	// header("Content-Disposition: attachment; filename=Data Pegawai.xls");
	// ?>
                        </button> -->



                    </div>
                    <br>
                    <a href="laporan.php" class="btn btn-danger noprint">Kembali</a>

        </div>  
        </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>
