<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Pembayaran SPP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <?php
        if ($_SESSION['level'] == "admin") {
        ?>
          <li class="nav-item">
            <a class="nav-link" href="siswa.php">Siswa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="spp.php">Spp</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="kelas.php">Kelas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="petugas.php">Petugas</a>
          </li>
        <?php
        }
        ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#x  " id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pembayaran Spp
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="transaksi.php">Transaksi</a></li>
            <li><a class="dropdown-item" href="history.php">History</a></li>
            <li><a class="dropdown-item" href="laporan.php">Laporan</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../logout.php">LogOut</a>
        </li>
      </ul>
    </div>
    <div style="margin-right:25px">
    <div class="form-inline">
      <span class="text-white">Welcome <strong><?= $_SESSION['username'] ?></strong></span>
    </div>
    </div>
  </div>
</nav>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>