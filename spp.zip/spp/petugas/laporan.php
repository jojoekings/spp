<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <?php
    include '../koneksi.php';
    session_start();


    include 'navbar.php';
    ?>

    <div class="container mt-3">
        <h2>Search data pembayaran</h2>
        <form action="" method="post">
            <input class="form-control" type="text" name="search" placeholder="Search.. ">
            <br>
            <input type="submit" class="btn btn-info"name="ser">
        </form>
        <br>
        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN</th>
                    <th>Tanggal bayar</th>
                    <th>Bulan di bayar</th>
                    <th>Tahun di bayar</th>
                    <th>Jumlah bayar</th>
                    <th>Laporan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include "../koneksi.php";
                if (isset($_POST['ser'])) {
                    $no = 1;
                    $search = $_POST['search'];



                    $query = mysqli_query($koneksi, "SELECT * FROM pembayaran where nisn='$search' or jumlah_bayar='$search'");
                    while ($d = mysqli_fetch_array($query)) {
                ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $d['nisn'] ?></td>
                            <td><?= $d['tgl_bayar'] ?></td>
                            <td><?= $d['bulan_bayar'] ?></td>
                            <td><?= $d['tahun_bayar'] ?></td>
                            <td>Rp.<?= number_format($d['jumlah_bayar'], 2, ",", ".") ?></td>
                            <td>
                                <a href="print.php?id_pembayaran=<?= $d['id_pembayaran'] ?>" class="btn btn-info">Detail</a>
                            </td>
                        </tr>
                    <?php $no++;
                    } ?>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>
