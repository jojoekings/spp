<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <?php
    session_start();
    include 'navbar.php';
    ?>
    <div class="container mt-5">
        <table class="table">
            <a href="tambah/tambah_siswa.php"><button type="button" class="btn btn-dark">Tambah Data Siswa</button></a>
            <br><br>
            <thead>
                <tr class="table-dark">
                    <th scope="col">No</th>
                    <th scope="col">Nisn</th>
                    <th scope="col">Nis</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Nama Kelas</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">no telp</th>
                    <th scope="col">Aksi</th>
                    <th scope="col">aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include '../koneksi.php';
                $query = 'select * from siswa join kelas on kelas.id_kelas=siswa.id_kelas';
                $data = mysqli_query($koneksi, $query);
                $no = 1;
                while ($row = mysqli_fetch_array($data)) {
                ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $row['nisn'] ?></td>
                        <td><?= $row['nis'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['nama_kelas'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                        <td><?= $row['no_telp'] ?></td>
                        <td>
                            <a href="edit/edit_siswa.php?nisn=<?= $row['nisn']; ?>" class="btn btn btn-warning">Edit</a>
                        </td>
                        <td>
                            <a href="aksi/delete_siswa.php?nisn=<?= $row['nisn']; ?>" class="btn btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                <?php $no++;
                } ?>
            </tbody>
        </table>
    </div>
</body>

</html>