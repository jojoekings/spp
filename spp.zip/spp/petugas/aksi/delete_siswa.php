<?php
include '../../koneksi.php';
$nisn = $_GET['nisn'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "call delete_siswa($nisn)";
$data = mysqli_query($koneksi,$query);

    //periksa query, apakah ada kesalahan
if(!$data) {
  die ("Gagal menghapus data: ".mysqli_errno($koneksi).
   " - ".mysqli_error($koneksi));
} else {
  echo "<script>alert('Data berhasil dihapus.');window.location='../siswa.php';</script>";
}