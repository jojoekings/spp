<?php
include '../../koneksi.php';
$id_kelas = $_GET['id_kelas'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "call delete_kelas($id_kelas)";
$data = mysqli_query($koneksi,$query);

    //periksa query, apakah ada kesalahan
if(!$data) {
  die ("Gagal menghapus data: ".mysqli_errno($koneksi).
   " - ".mysqli_error($koneksi));
} else {
  echo "<script>alert('Data berhasil dihapus.');window.location='../kelas.php';</script>";
}