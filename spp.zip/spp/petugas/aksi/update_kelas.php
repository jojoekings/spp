<?php 
    include '../../koneksi.php';

    $nama_kelas = $_POST ['nama_kelas']; 
    $kompetensi_keakhlian = $_POST ['kompetensi_keakhlian'];
    $id_kelas = $_POST ['id_kelas'];

    $query = "call upd_kelas('$nama_kelas','$kompetensi_keakhlian',$id_kelas)";
    $data = mysqli_query($koneksi, $query);

    if(!$data) {
        die ("Gagal menghapus data: ".mysqli_errno($koneksi).
         " - ".mysqli_error($koneksi));
      } else {
        echo "<script>alert('Data berhasil diupdate.');window.location='../kelas.php';</script>";
      }
?>