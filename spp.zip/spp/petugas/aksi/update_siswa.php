<?php 
    include '../../koneksi.php';

    $nisn = $_POST ['nisn'];
    $nis = $_POST ['nis']; 
    $nama = $_POST ['nama'];
    $id_kelas = $_POST ['id_kelas'];
    $alamat = $_POST ['alamat']; 
    $no_telp = $_POST ['no_telp'];
    $password = $_POST ['password'];

    $query = "call upd_siswa('$nis','$nama',$id_kelas,'$alamat','$no_telp','$password','$nisn')";
    $data = mysqli_query($koneksi, $query);

    if(!$data) {
        die ("Gagal menghapus data: ".mysqli_errno($koneksi).
         " - ".mysqli_error($koneksi));
      } else {
        echo "<script>alert('Data berhasil diupdate.');window.location='../siswa.php';</script>";
      }
?>