<?php 
    include '../../koneksi.php';

    $username = $_POST ['username'];
    $password = $_POST ['password'];
    $nama_petugas = $_POST ['nama_petugas']; 
    $level = $_POST ['level']; 
    $id_petugas = $_POST ['id_petugas'];
    
    $query = "call upd_petugas('$username','$password','$nama_petugas','$level',$id_petugas)";
    $data = mysqli_query($koneksi, $query);

    if(!$data) {
        die ("Gagal menghapus data: ".mysqli_errno($koneksi).
         " - ".mysqli_error($koneksi));
      } else {
        echo "<script>alert('Data berhasil diupdate.');window.location='../petugas.php';</script>";
      }
?>