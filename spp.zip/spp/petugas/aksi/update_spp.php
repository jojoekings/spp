<?php 
    include '../../koneksi.php';

    $tahun = $_POST ['tahun'];
    $nominal = $_POST ['nominal']; 
    $id_spp = $_POST ['id_spp'];

    $query = "call upd_spp('$tahun','$nominal',$id_spp)";
    $data = mysqli_query($koneksi, $query);

    if(!$data) {
        die ("Gagal menghapus data: ".mysqli_errno($koneksi).
         " - ".mysqli_error($koneksi));
      } else {
        echo "<script>alert('Data berhasil diupdate.');window.location='../spp.php';</script>";
      }
?>