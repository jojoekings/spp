<?php
include '../../koneksi.php';
$id_spp = $_GET['id_spp'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "call delete_spp($id_spp)";
$data = mysqli_query($koneksi,$query);

    //periksa query, apakah ada kesalahan
if(!$data) {
  die ("Gagal menghapus data: ".mysqli_errno($koneksi).
   " - ".mysqli_error($koneksi));
} else {
  echo "<script>alert('Data berhasil dihapus.');window.location='../spp.php';</script>";
}