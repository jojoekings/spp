<?php
include '../../koneksi.php';
$id_kelas = $_GET['id_kelas'];

$query = "select * from kelas where id_kelas=$id_kelas";
$data = mysqli_query($koneksi, $query);
$row = mysqli_fetch_array($data);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        Featured
      </div>
      <div class="card-body">
        <form class="row g-3" action="../aksi/update_kelas.php" method="post">
          <input type="hidden" name="id_kelas" value="<?= $row['id_kelas'] ?>">
          <div class="col-md-6">
            <label for="" class="form-label">Nama Kelas</label>
            <input type="text" name="nama_kelas" class="form-control" value="<?= $row['nama_kelas'] ?>">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">Kompetensi Keakhlian</label>
            <input type="text" name="kompetensi_keakhlian" class="form-control" value="<?= $row['kompetensi_keakhlian'] ?>">
          </div>
          <input type="submit" value="simpan">
        </form>
      </div>
    </div>
  </div>
</body>

</html>