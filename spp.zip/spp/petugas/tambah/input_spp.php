<?php 
    include '../../koneksi.php';

    $tahun = $_POST ['tahun'];
    $nominal = $_POST ['nominal']; 

    $query = "call input_spp('$tahun','$nominal')";
    $data = mysqli_query($koneksi, $query);
    header("location:../spp.php");
?>