<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        Featured
      </div>
      <div class="card-body">
        <form class="row g-3" action="input_siswa.php" method="post">
          <div class="col-md-6">
            <label for="" class="form-label">Nisn</label>
            <input type="text" name="nisn" class="form-control">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">Nis</label>
            <input type="text" name="nis" class="form-control">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">kelas</label>
            <select name="id_kelas" id="id_kelas" class="form-select">
              <?php
              include '../../koneksi.php';
              $data = mysqli_query($koneksi, "select * from kelas");
              while ($d = mysqli_fetch_array($data)) {
              ?>
                <option value="<?= $d['id_kelas'] ?>"><?= $d['nama_kelas'] ?></option>
              <?php
              }
              ?>
            </select>
          </div>
          <div class="col-md-12">
            <label for="" class="form-label">Alamat</label>
            <input type="text" name="alamat" class="form-control">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">No Telepon</label>
            <input type="text" name="no_telp" class="form-control">
          </div>
          <div class="col-md-6">
            <label for="" class="form-label">Passsword</label>
            <input type="passsword" name="password" class="form-control">
          </div>
          <input type="submit" value="simpan">
        </form>
      </div>
    </div>
  </div>
</body>

</html>