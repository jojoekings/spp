<?php 
    include '../../koneksi.php';

    $nama_kelas = $_POST ['nama_kelas'];
    $kompetensi_keakhlian = $_POST ['kompetensi_keakhlian']; 

    $query = "CALL input_kelas('$nama_kelas','$kompetensi_keakhlian')";
    $data = mysqli_query($koneksi, $query);
    header("location:../kelas.php");
?>