<?php 
    include '../../koneksi.php';

    $id_petugas = $_POST ['id_petugas']; 
    $nisn = $_POST ['nisn'];
    $tgl_bayar = $_POST ['tgl_bayar'];
    $bulan_bayar = $_POST ['bulan_bayar']; 
    $tahun_bayar = $_POST ['tahun_bayar'];
    $id_spp = $_POST ['id_spp'];
    $jumlah_bayar = $_POST ['jumlah_bayar'];

    $query = "call input_pembayaran('$id_petugas','$nisn','$tgl_bayar','$bulan_bayar','$tahun_bayar','$id_spp','$jumlah_bayar')";
    $data = mysqli_query($koneksi, $query);
    header("location:../history.php");
?>