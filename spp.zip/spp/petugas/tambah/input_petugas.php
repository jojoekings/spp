<?php 
    include '../../koneksi.php';

    $username = $_POST ['username'];
    $password = $_POST ['password']; 
    $nama_petugas = $_POST ['nama_petugas'];
    $level = $_POST ['level']; 

    $query = "call input_petugas('$username','$password','$nama_petugas','$level')";
    $data = mysqli_query($koneksi, $query);
    header("location:../petugas.php");
?>